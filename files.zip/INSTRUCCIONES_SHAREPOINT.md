# Configurar Guía de Atención en SharePoint
## Tiempo estimado: 15-20 minutos

---

## PASO 1 — Crear la lista SharePoint

1. Abre tu sitio SharePoint en el navegador
2. Click en **"+ Nuevo"** → **"Lista"**
3. Elige **"Desde CSV"** (o "Desde archivo Excel")
4. Sube el archivo `causas_sheets.csv`
5. **Nombre de la lista:** `CausasCallCenter` (exactamente así, sin espacios)
6. Click **Crear**

> SharePoint creará automáticamente todas las columnas desde el CSV.

---

## PASO 2 — Verificar las columnas

Asegúrate que la lista tiene estas columnas (SharePoint las crea desde el CSV):

| Columna | Tipo |
|---------|------|
| id | Línea de texto |
| numero | Línea de texto |
| familia | Línea de texto |
| subfamilia | Línea de texto |
| cuando_aplica | Varias líneas de texto |
| tipo | Línea de texto |
| manual_ficha | Línea de texto |
| tipificacion | Línea de texto |
| causa_reclamo | Línea de texto |
| proceso_resolucion | Varias líneas de texto |
| script_rrss | Varias líneas de texto |
| tiene_wizard | Línea de texto |

---

## PASO 3 — Subir el HTML a SharePoint

1. Ve a una biblioteca de documentos de tu sitio (ej: "Documentos")
2. Sube el archivo `guia_atencion_sharepoint.html`
3. **Click derecho** sobre el archivo → **"Copiar link"**
4. Ese link es el que compartirás con los 70 ejecutivos ✅

---

## PASO 4 — Primera apertura (configuración)

Al abrir el HTML por primera vez aparecerá una pantalla de configuración:

1. **URL del sitio SharePoint:** copia la URL de tu sitio, ejemplo:
   `https://tuempresa.sharepoint.com/sites/callcenter`
   *(todo hasta el nombre del sitio, sin barra al final)*

2. **Nombre de la lista:** `CausasCallCenter`

3. Click **"Conectar →"**

La configuración se guarda en ese navegador. Cada ejecutivo la configura una sola vez.

---

## PASO 5 — Dar acceso a los ejecutivos

1. La lista `CausasCallCenter` debe tener permisos de **lectura** para todos los ejecutivos
2. En SharePoint: engranaje ⚙ → **Configuración del sitio** → **Permisos del sitio** → agrega a los ejecutivos como "Visitantes" (solo lectura)

---

## Cómo actualiza el supervisor

1. Abre la lista `CausasCallCenter` en SharePoint
2. Edita cualquier fila directamente (como una tabla de Excel en el navegador)
3. Los ejecutivos ven los cambios al hacer click en **↺ Actualizar** en la barra superior de la guía

### Para agregar una causa nueva:
1. En la lista SharePoint → **"+ Nuevo"**
2. Completa los campos
3. En `script_rrss`: escribe el script completo usando `Indicación para el ejecutivo:` para separar instrucciones de los scripts al cliente

---

## Contraseña supervisor (panel interno)
`supervisor2026`

---

## Solución de problemas

**"No se pudo conectar"**: Verifica que la URL no tenga barra final y que el nombre de la lista sea exactamente `CausasCallCenter`

**"Lista vacía"**: Asegúrate de haber importado el CSV correctamente en el Paso 1

**Los ejecutivos no ven los datos**: Verificar permisos de lectura en la lista SharePoint
